 See README.md


This folder will hold the faces of training images.
